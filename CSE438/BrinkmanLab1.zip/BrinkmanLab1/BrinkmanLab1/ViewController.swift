//
//  ViewController.swift
//  BrinkmanLab1
//
//  Created by John W Brinkman on 6/14/18.
//  Copyright © 2018 John W Brinkman. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var endPrice: UILabel!
    @IBOutlet weak var discount: UITextField!
    @IBOutlet weak var originalPrice: UITextField!
    @IBOutlet weak var salesTax: UITextField!
    @IBAction func priceAction(_ sender: UITextField) {
        endPrice.text = "$ \(String(describing: originalPrice.text))"
     
    }
   
    @IBAction func salesTaxAction(_ sender: UITextField) {
    
    }
    @IBAction func discountAction(_ sender: UITextField) {
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    func changePrice(){
        let finalPrice = originalPrice.text
        
        endPrice.text = "$ \(String(describing: finalPrice))"
    }

}

