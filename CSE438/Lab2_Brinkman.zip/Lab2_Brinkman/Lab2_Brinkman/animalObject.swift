//
//  animalObject.swift
//  Lab2_Brinkman
//
//  Created by John W Brinkman on 6/26/18.
//  Copyright © 2018 John W Brinkman. All rights reserved.
//

import Foundation
import UIKit
class animal {
    var name:String
    var foodAmount:Int = 0
    var happinessLevel:Int = 0
    var color:UIColor
    var image:UIImage
    init(color:UIColor, image:UIImage, name:String) {
        self.color = color
        self.image = image
        self.name = name
    }
    func feed(){
        foodAmount+=1
    }
    func pet(){
        if(foodAmount > 0 && happinessLevel < 8){
            happinessLevel += 1
        }
    }
    func play(){
        if(foodAmount > 0){
            happinessLevel += 1
            foodAmount -= 1
        }
    }
}



