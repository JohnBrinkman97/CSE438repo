//
//  ViewController.swift
//  Lab2_Brinkman
//
//  Created by John W Brinkman on 6/25/18.
//  Copyright © 2018 John W Brinkman. All rights reserved.
//

import UIKit
import AVFoundation
class ViewController: UIViewController {

    @IBOutlet weak var petImage: UIImageView!
    @IBOutlet weak var imageBackground: UIView!
    var player: AVAudioPlayer?
    
    var bunny = animal(color: UIColor.green, image: #imageLiteral(resourceName: "Bunny"),name: "bunny")
    var dog = animal(color: UIColor.red,image: #imageLiteral(resourceName: "Dog"),name: "dog")
    var cat = animal(color: UIColor.blue,image: #imageLiteral(resourceName: "Cat"),name: "cat")
    var fish = animal(color: UIColor.orange,image: #imageLiteral(resourceName: "Fish"),name: "fish")
    var bird = animal(color: UIColor.yellow,image: #imageLiteral(resourceName: "Bird"),name: "bird")
    var chosenPet:animal?
    var petArray:[animal] = Array()
    
    @IBOutlet weak var happinessNum: UILabel!
    @IBOutlet weak var happinessBar: DisplayView!
    @IBOutlet weak var foodBar: DisplayView!
    @IBOutlet weak var foodNum: UILabel!
    
    @IBAction func dogButton(_ sender: Any) {
        chosenPet = dog
        bark()
        changePet()
    }
    @IBAction func feedPet(_ sender: Any) {
        for pet in petArray{
            if pet.name == chosenPet?.name{
                pet.feed()
                updateBars()
            }
        }
    }
    @IBAction func playWithPet(_ sender: Any) {
        for pet in petArray{
            if pet.name == chosenPet?.name{
                pet.play()
                updateBars()
            }
        }
    }
    @IBAction func petPet(_ sender: Any) {
        print("image tapped")
        for pet in petArray{
            if pet.name == chosenPet?.name && chosenPet?.name != "fish"{
                pet.pet()
                updateBars()
            }
            else if chosenPet?.name == "fish" && pet.happinessLevel > 0{
                pet.happinessLevel -= 1
                updateBars()
            }
        }
    }
    
    @IBAction func catButton(_ sender: Any) {
        chosenPet = cat
        meow()
        changePet()
        
    }
    @IBAction func birdbutton(_ sender: Any) {
        chosenPet = bird
        squawk()
        changePet()
    }
    @IBAction func bunnyButton(_ sender: Any) {
        chosenPet = bunny
        bugsBunny()
        changePet()
    }
    @IBAction func fishButton(_ sender: Any) {
        chosenPet = fish
        floppingFish()
        changePet()
    }
    
   
    
   
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        foodBar.value=10
        happinessBar.value=10
        petArray = [bird,dog,cat,bunny,fish]
        chosenPet = dog
        changePet()
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    func changePet(){
        if let image = chosenPet?.image{
           petImage.image = image
        }
        if let color = chosenPet?.color{
        foodBar.color = color
        happinessBar.color = color
        imageBackground.backgroundColor = color
        }
        updateBars()
    }
    func updateBars(){
        if let value = chosenPet?.foodAmount{
            foodBar.animateValue(to: CGFloat(Double(value)/10.0))
            foodNum.text=String(value)
        }
        if let value = chosenPet?.happinessLevel{
            happinessBar.animateValue(to: CGFloat(Double(value)/10.0))
            happinessNum.text=String(value)
           
        }
    }
    func bark(){
        guard let url = Bundle.main.url(forResource: "bark", withExtension: "mp3") else { return }
        
        do {
            try AVAudioSession.sharedInstance().setCategory(AVAudioSessionCategoryPlayback)
            try AVAudioSession.sharedInstance().setActive(true)
            
            
            
            /* The following line is required for the player to work on iOS 11. Change the file type accordingly*/
            player = try AVAudioPlayer(contentsOf: url, fileTypeHint: AVFileType.mp3.rawValue)
            
            /* iOS 10 and earlier require the following line:
             player = try AVAudioPlayer(contentsOf: url, fileTypeHint: AVFileTypeMPEGLayer3) */
            
            guard let player = player else { return }
            
            player.play()
            
        } catch let error {
            print(error.localizedDescription)
        }
    }
    /*
    all sound code from https://stackoverflow.com/questions/32036146/how-to-play-a-sound-using-swift
    */
    func squawk(){
        guard let url = Bundle.main.url(forResource: "squawk", withExtension: "mp3") else { return }
        
        do {
            try AVAudioSession.sharedInstance().setCategory(AVAudioSessionCategoryPlayback)
            try AVAudioSession.sharedInstance().setActive(true)
            
            
            
            /* The following line is required for the player to work on iOS 11. Change the file type accordingly*/
            player = try AVAudioPlayer(contentsOf: url, fileTypeHint: AVFileType.mp3.rawValue)
            
            /* iOS 10 and earlier require the following line:
             player = try AVAudioPlayer(contentsOf: url, fileTypeHint: AVFileTypeMPEGLayer3) */
            
            guard let player = player else { return }
            
            player.play()
            
        } catch let error {
            print(error.localizedDescription)
        }
    }
    func meow(){
        guard let url = Bundle.main.url(forResource: "meow", withExtension: "mp3") else { return }
        
        do {
            try AVAudioSession.sharedInstance().setCategory(AVAudioSessionCategoryPlayback)
            try AVAudioSession.sharedInstance().setActive(true)
            
            
            
            /* The following line is required for the player to work on iOS 11. Change the file type accordingly*/
            player = try AVAudioPlayer(contentsOf: url, fileTypeHint: AVFileType.mp3.rawValue)
            
            /* iOS 10 and earlier require the following line:
             player = try AVAudioPlayer(contentsOf: url, fileTypeHint: AVFileTypeMPEGLayer3) */
            
            guard let player = player else { return }
            
            player.play()
            
        } catch let error {
            print(error.localizedDescription)
        }
    }
    func bugsBunny(){
        guard let url = Bundle.main.url(forResource: "bugs02", withExtension: "mp3") else { return }
        
        do {
            try AVAudioSession.sharedInstance().setCategory(AVAudioSessionCategoryPlayback)
            try AVAudioSession.sharedInstance().setActive(true)
            
            
            
            /* The following line is required for the player to work on iOS 11. Change the file type accordingly*/
            player = try AVAudioPlayer(contentsOf: url, fileTypeHint: AVFileType.mp3.rawValue)
            
            /* iOS 10 and earlier require the following line:
             player = try AVAudioPlayer(contentsOf: url, fileTypeHint: AVFileTypeMPEGLayer3) */
            
            guard let player = player else { return }
            
            player.play()
            
        } catch let error {
            print(error.localizedDescription)
        }
    }
    func floppingFish(){
        guard let url = Bundle.main.url(forResource: "fish", withExtension: "mp3") else { return }
        
        do {
            try AVAudioSession.sharedInstance().setCategory(AVAudioSessionCategoryPlayback)
            try AVAudioSession.sharedInstance().setActive(true)
            
            
            
            /* The following line is required for the player to work on iOS 11. Change the file type accordingly*/
            player = try AVAudioPlayer(contentsOf: url, fileTypeHint: AVFileType.mp3.rawValue)
            
            /* iOS 10 and earlier require the following line:
             player = try AVAudioPlayer(contentsOf: url, fileTypeHint: AVFileTypeMPEGLayer3) */
            
            guard let player = player else { return }
            
            player.play()
            
        } catch let error {
            print(error.localizedDescription)
        }
    }
}

