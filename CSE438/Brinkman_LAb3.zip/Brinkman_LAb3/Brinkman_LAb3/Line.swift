//
//  Line.swift
//  Lab3_Brinkman
//
//  Created by John W Brinkman on 7/2/18.
//  Copyright © 2018 John W Brinkman. All rights reserved.
//

import Foundation
import UIKit

struct Line{
   
    var points:[CGPoint]
    var color:UIColor
    var thickness:CGFloat
}

