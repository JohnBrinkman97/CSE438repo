//
//  ViewController.swift
//  Brinkman_Lab3
//
//  Created by John W Brinkman on 6/30/18.
//  Copyright © 2018 John W Brinkman. All rights reserved.
//

import UIKit
import Photos
extension UIView {
    
    /* extension from
 https://stackoverflow.com/questions/30696307/how-to-convert-a-uiview-to-an-image/47003078
 */
    func asImage() -> UIImage {
        let renderer = UIGraphicsImageRenderer(bounds: bounds)
        return renderer.image { rendererContext in
            layer.render(in: rendererContext.cgContext)
        }
    }
}
class ViewController: UIViewController{
    var lineCanvas:drawView!
    var currentLine:Line?
    var lines:[Line] = []
    var first:CGPoint?
    var touchArray:[CGPoint] = []
    var currentPathColor = UIColor.magenta

    var status = PHPhotoLibrary.authorizationStatus()
    var currentPathThickness:CGFloat = 50.0
   
    @IBOutlet weak var stack: UIStackView!
    
    @IBOutlet weak var sliderVal: UISlider!
   
    @IBAction func slider(_ sender: Any) {
        currentPathThickness = CGFloat(sliderVal.value)
        
    }
    @IBAction func shareButton(_ sender: Any) {
        lineCanvas.willRemoveSubview(stack)
        stack.removeFromSuperview()
        /* rest of function is from
       https://stackoverflow.com/questions/35931946/basic-example-for-sharing-text-or-image-with-uiactivityviewcontroller-in-swift
         */
        let image = lineCanvas
        // set up activity view controller
      
        let imageData = UIImageJPEGRepresentation((image?.asImage())!, 0.6)
        let compressedJPGImage = UIImage(data: imageData!) as Any
        let activityViewController = UIActivityViewController(activityItems: [compressedJPGImage], applicationActivities: nil)
        activityViewController.popoverPresentationController?.sourceView = self.view // so that iPads won't crash
        
        // exclude some activity types from the list (optional)
        activityViewController.excludedActivityTypes = [ UIActivityType.airDrop, UIActivityType.postToFacebook ]
        
        // present the view controller
      self.present(activityViewController, animated: true, completion: nil)
      
      self.lineCanvas.addSubview(stack)
       activityViewController.completionWithItemsHandler = {(activityType: UIActivityType?, completed: Bool, returnedItems: [Any]?, error: Error?) in
            if !completed {
               
                return
            }
            self.clear()
        
        }
        
    }
    
    @IBAction func saveButton(_ sender: Any) {

        lineCanvas.willRemoveSubview(stack)
        stack.removeFromSuperview()
        /* rest of function is from
         https://turbofuture.com/cell-phones/Access-Photo-Camera-and-Library-in-Swift
         */
        let imagePicked = lineCanvas
        let imageData = UIImageJPEGRepresentation((imagePicked?.asImage())!, 0.6)
        let compressedJPGImage = UIImage(data: imageData!)
        UIImageWriteToSavedPhotosAlbum(compressedJPGImage!, nil, nil, nil)
        var alert = UIAlertController(title: "Photo Saved!", message: "Photo saved to library", preferredStyle: .alert)
        status = PHPhotoLibrary.authorizationStatus()
        print(status)
        if status != PHAuthorizationStatus.denied{
       
        alert.addAction(UIAlertAction(title: NSLocalizedString("OK", comment: "Default action"), style: .default, handler: { _ in
            NSLog("The \"OK\" alert occured.") // https://developer.apple.com/documentation/uikit/uialertcontroller?changes=_4
        }))
        }else if status == PHAuthorizationStatus.denied{
            alert = UIAlertController(title: "Photo Not Saved!", message: "Change photo privacy settings", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: NSLocalizedString("OK", comment: "Default action"), style: .default, handler: { _ in
                NSLog("The \"OK\" alert occured.") // https://developer.apple.com/documentation/uikit/uialertcontroller?changes=_4
            }))
        }
        self.present(alert, animated: true)
        clear()
        self.viewDidLoad()
    }

   
    @IBAction func undoButton(_ sender: Any) {
        if lines.count >= 1{
        lines.remove(at: lines.count-1)
        lineCanvas.lines = lines
        lineCanvas.theLine = nil
    
        }
    }
    
    @IBAction func clearButton(_ sender: Any) {
    clear()
        
    }
    func clear(){
        lines = []
        lineCanvas.lines = []
        currentLine = nil
        lineCanvas.theLine = nil
    }
    @IBOutlet weak var pink: colorButtons!
    
    @IBOutlet weak var red: colorButtons!
    @IBOutlet weak var yellow: colorButtons!
    @IBOutlet weak var purple: colorButtons!
    @IBOutlet weak var orange: colorButtons!
    @IBOutlet weak var green: colorButtons!
    @IBOutlet weak var blue: colorButtons!
    @IBAction func pinkButton(_ sender: Any) {
        resetBorders()
        currentPathColor = UIColor.magenta
        pink.layer.borderWidth = 3
    }
    @IBAction func blueButton(_ sender: Any) {
         resetBorders()
        currentPathColor = UIColor.blue
        blue.layer.borderWidth = 3
    }
    @IBAction func greenButton(_ sender: Any) {
         resetBorders()
        currentPathColor = UIColor.green
        green.layer.borderWidth = 3
        
    }
    @IBAction func orangeButton(_ sender: Any) {
         resetBorders()
        currentPathColor = UIColor.orange
        orange.layer.borderWidth = 3
    }
    @IBAction func purpleButton(_ sender: Any) {
         resetBorders()
        currentPathColor = UIColor.purple
        purple.layer.borderWidth = 3
    }
    
    @IBAction func yelllowButton(_ sender: Any) {
         resetBorders()
        currentPathColor = UIColor.yellow
        yellow.layer.borderWidth = 3
    }
    
    @IBAction func redButton(_ sender: Any) {
         resetBorders()
        currentPathColor = UIColor.red
        red.layer.borderWidth = 3
    }
    func resetBorders(){
         blue.layer.borderWidth = 0
         orange.layer.borderWidth = 0
         green.layer.borderWidth = 0
         yellow.layer.borderWidth = 0
         pink.layer.borderWidth = 0
         purple.layer.borderWidth = 0
         red.layer.borderWidth = 0
        
    }

    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor.white
      
        // Do any additional setup after loading the view, typically from a nib.
        lineCanvas = drawView(frame: self.view.frame)
         lineCanvas.backgroundColor = UIColor.white
        view.addSubview(lineCanvas)
        lineCanvas.addSubview(stack)
        resetBorders()
        pink.layer.borderWidth = 3
       
       
    }
  
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard let touchPoint = touches.first?.location(in: view) else { return }
        first = touchPoint
        touchArray = []
    }
    
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
     
        lines.append(currentLine!)
        lineCanvas.lines = lines
    
        lineCanvas.theLine = nil
    }
    
    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard let touchPoint = touches.first?.location(in: view) else { return }
        
        touchArray.append(touchPoint)
       
        currentLine = Line(points: touchArray, color: currentPathColor, thickness: currentPathThickness)
        lineCanvas.theLine = currentLine
    }
   

}

