//
//  drawView.swift
//  Lab3_Brinkman
//
//  Created by John W Brinkman on 6/30/18.
//  Copyright © 2018 John W Brinkman. All rights reserved.
//

import UIKit

class drawView: UIView {

    var lines:[Line] = [] {
        didSet {
            setNeedsDisplay()
        }
    }
    
    var theLine:Line? {
        didSet {
            setNeedsDisplay()
        }
    }
    
    var pathColor:UIColor = UIColor.clear
    var pathWidth:CGFloat = 25.0
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.backgroundColor = UIColor.clear
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    private func midpoint(first: CGPoint, second: CGPoint) -> CGPoint {
        // implement this function here
        let midX = (Double(first.x) + Double(second.x))/2.0
        let midY = (Double(first.y) + Double(second.y))/2.0
        return CGPoint(x: CGFloat(midX), y: CGFloat(midY))
    }
    func createQuadPath(points: [CGPoint]) -> UIBezierPath {
        let path = UIBezierPath()
        if points.count < 2 { return path }
        let firstPoint = points[0]
        let secondPoint = points[1]
        let firstMidpoint = midpoint(first: firstPoint, second: secondPoint)
        path.move(to: firstPoint)
        path.addLine(to: firstMidpoint)
        for index in 1 ..< points.count-1 {
            let currentPoint = points[index]
            let nextPoint = points[index + 1]
            let midPoint = midpoint(first: currentPoint, second: nextPoint)
            path.addQuadCurve(to: midPoint, controlPoint: currentPoint)
        }
        guard let lastLocation = points.last else { return path }
        path.addLine(to: lastLocation)
        return path
    }
    override func draw(_ rect: CGRect) {
        // Drawing code
        
        for line in lines {
        let path = createQuadPath(points: line.points)
            pathColor = line.color
            pathWidth = line.thickness
            drawLine(path: path)
        }
        
        if(theLine != nil) {
            let path = createQuadPath(points: (theLine?.points)!)
            pathColor = (theLine?.color)!
            pathWidth = (theLine?.thickness)!
            drawLine(path: path)
        }
    }
    func drawLine(path: UIBezierPath){
        let path = path
        path.lineWidth = pathWidth
        print(pathWidth)
        pathColor.setStroke()
        path.lineJoinStyle = .round
        path.lineCapStyle = .round
        path.stroke()
        
    }

}
