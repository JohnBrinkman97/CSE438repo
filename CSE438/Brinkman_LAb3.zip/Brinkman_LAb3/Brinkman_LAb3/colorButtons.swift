//
//  colorButtons.swift
//  Lab3_Brinkman
//
//  Created by John W Brinkman on 6/30/18.
//  Copyright © 2018 John W Brinkman. All rights reserved.
//

import UIKit
@IBDesignable
class colorButtons:UIButton {

    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */

    

        
    @IBInspectable var color: UIColor = UIColor.clear{
        didSet{
            self.layer.backgroundColor = color.cgColor
            self.layer.cornerRadius = self.frame.width/2.0
            self.clipsToBounds = true
            self.layer.borderWidth = 0
            self.titleLabel?.text = ""
            
        }
    }
   
    
     
}
