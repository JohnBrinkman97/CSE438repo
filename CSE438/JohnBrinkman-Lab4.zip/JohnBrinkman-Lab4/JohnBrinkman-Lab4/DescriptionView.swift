//
//  DescriptionView.swift
//  JohnBrinkman-Lab4
//
//  Created by John W Brinkman on 7/12/18.
//  Copyright © 2018 John W Brinkman. All rights reserved.
//

import UIKit

class DescriptionView: UIViewController {
    var overview:String!
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor.white
        let theTextFrame = CGRect(x: 0, y: 5, width: view.frame.width - 5, height: view.frame.height)
        let textView = UILabel(frame: theTextFrame)
        textView.text = overview
        textView.numberOfLines = 0
        textView.lineBreakMode = .byWordWrapping
        textView.textAlignment = .center
        view.addSubview(textView)
        let buttonFrame = CGRect(x: 0, y: 35, width: view.frame.width/4, height: 20)
        let button = UIButton(frame: buttonFrame)
        
        button.setTitle("Cancel", for: .normal)
        button.setTitleColor(UIColor.blue, for: .normal)
        button.addTarget( self, action: #selector(self.onCancelButton(button:)), for: .touchUpInside)
        view.addSubview(button)
    }
    @objc func onCancelButton(button: UIBarButtonItem){
        self.dismiss(animated: true, completion: nil)
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
