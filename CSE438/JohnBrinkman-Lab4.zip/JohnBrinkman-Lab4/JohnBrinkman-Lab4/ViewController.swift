//
//  ViewController.swift
//  JohnBrinkman-Lab4
//
//  Created by John W Brinkman on 7/11/18.
//  Copyright © 2018 John W Brinkman. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UISearchBarDelegate, UICollectionViewDataSource,UICollectionViewDelegate, UICollectionViewDelegateFlowLayout, sendBack{
   
    
 @IBOutlet weak var searchBar: UISearchBar!
    
   
    var theData:APIResults?
    var searchData:String = ""
    var theImageCache: [UIImage] = []
    var spinner:UIActivityIndicatorView = UIActivityIndicatorView(activityIndicatorStyle: .whiteLarge)
    var currentPage = 1
    var waiting:Bool = false
    var allowed:Bool = false
    var chosenGenre:Int?{
        didSet{
            getTop20()
        }
    }
    
    let dq = DispatchQueue.global(qos: .userInitiated)
    @IBOutlet weak var collectionView: UICollectionView!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        searchBar.delegate = self
        collectionView.dataSource = self
        collectionView.delegate = self
       
        collectionView.register(UICollectionViewCell.self, forCellWithReuseIdentifier: "cell")
        spinnerSetup()
        
    }
    func spinnerSetup(){
        spinner.color = UIColor.red
        spinner.hidesWhenStopped = true
        spinner.frame = collectionView.frame
        spinner.center = collectionView.center
        view.addSubview(spinner)
       
        
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    func getData(){
            //view.bringSubview(toFront: spinner)
            spinner.startAnimating()
            DispatchQueue.global(qos: .userInitiated).async
                {
                    //fetch data from JSON for Tableview
                    self.fetchJSONData()
                    
                    DispatchQueue.main.async {
                    self.collectionView.reloadData()
                    self.spinner.stopAnimating()
                    self.waiting = true
                        
                    }
            }
   
    }
    func fetchJSONData() {
        searchData = searchData.trimmingCharacters(in: .whitespacesAndNewlines)
        searchData = searchData.addingPercentEncoding(withAllowedCharacters: .urlHostAllowed)!
       
        if(searchData.isEmpty != true){
        let url = URL(string:"https://api.themoviedb.org/3/search/movie?api_key=3040d0a153f1c0e14e4ca405896776c6&query=\(searchData)&include_adult=false&language=en-US")
        let data = try! Data(contentsOf: url!)
        theData = try! JSONDecoder().decode(APIResults.self, from: data)
            fetchPosterImages(movieArray: (theData?.results)!)
        }
    }
    func moreData(){ // load more data after initial page of movies is scrolled through
    
     
        dq.async {
            if let count = self.theData?.total_pages{
                if count > self.currentPage+1{ //if there are more pages
                    // using the spinner in the top bar allows the user to know that the feed is updating, without actually interrupting their scrolling like the spinner was doing
                    DispatchQueue.main.async {
                    UIApplication.shared.isNetworkActivityIndicatorVisible = true
                    }
                    if(self.searchData.isEmpty != true){ //if there is a search query
                        self.currentPage += 1
                       
                        let url = URL(string:"https://api.themoviedb.org/3/search/movie?api_key=3040d0a153f1c0e14e4ca405896776c6&query=\(self.searchData)&page=\(self.currentPage)&include_adult=false&language=en-US") // url with next page number
                        let data = try! Data(contentsOf: url!)
                        let temp = try! JSONDecoder().decode(APIResults.self, from: data)
                        for movie in temp.results{
                            if self.allowed{
                            self.theData?.results.append(movie)
                            }
                        }
                        
                        self.fetchPosterImages(movieArray: temp.results)
                        DispatchQueue.main.async {
                            self.waiting = true
                            //self.spinner.stopAnimating()
                            UIApplication.shared.isNetworkActivityIndicatorVisible = false // replaces spinner
                            self.collectionView.reloadData() //update collection view
                            
                        }
                    }
                }
            }
           
        }
    }
    
    func searchBarTextDidEndEditing(_ searchBar: UISearchBar) {
        searchBar.resignFirstResponder()
        // after the user finishes editing, perform the search
        if searchData.isEmpty == true {
            return
        } else {
            currentPage = 1
            theData?.results = []
            theImageCache = []
            allowed = false
            getData()
        }
    }
    
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        searchBar.resignFirstResponder()
    }
    
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        searchBar.resignFirstResponder()
    }
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        searchData = searchText
    }

    
    func fetchPosterImages(movieArray:[Movie]){

            for item in (movieArray) {
            let defaultImage = "8uO0gUM8aNqYLs1OsTBQiXu0fEv.jpg" // just a random image.. url is nil without it for some reason (not sure why the if statement doesn't prevent that, the 'noImage' image is used anyway)
            if item.poster_path != nil{
            let url = URL(string: "https://image.tmdb.org/t/p/original/\(item.poster_path ?? defaultImage )")
            let data = try? Data(contentsOf: url!)
            let image  = UIImage(data: data!)
            self.theImageCache.append(image!)
            }else{
                let image = #imageLiteral(resourceName: "image_unavailable.png")
                self.theImageCache.append(image)
                }
            }
        
    }
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if let count = theData?.results.count{
        return count
        }
        else { return 0 }
    }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        //setup cell
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath)
        //setup image
        let imageView = UIImageView(frame: CGRect(x: 0, y: 0, width: cell.frame.width, height: cell.frame.height))
        imageView.image = theImageCache[indexPath.row]
      
        imageView.contentMode = UIViewContentMode.scaleToFill
        cell.contentView.addSubview(imageView)
        //setup title
        cell.backgroundColor = UIColor.black
        let text = UILabel(frame: CGRect(x: 0, y: cell.frame.height-cell.frame.height/3 , width: cell.frame.width, height: cell.frame.height/3))
        text.font = UIFont.systemFont(ofSize: UIFont.labelFontSize)
        text.textAlignment = .center
        text.textColor = UIColor.white
        text.numberOfLines = 0
        text.lineBreakMode = .byWordWrapping
        text.backgroundColor = UIColor.init(red: 0, green: 0, blue: 0, alpha: 0.7)
        text.text = theData?.results[indexPath.row].title
        cell.contentView.addSubview(text)
        if indexPath.row == (theData?.results.count)! - 3 && waiting == true{  //numberofitem count
            allowed = true
            moreData()
            waiting = false
          
        }
        return cell
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize{
        let width = (collectionView.bounds.width/3.0) - 5
        let height = (collectionView.bounds.height/3.0) - 5
        
        return CGSize(width: width, height: height)
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        return UIEdgeInsets.zero
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 5
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 5
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let detailedVC = DetailedViewController()
        detailedVC.image = theImageCache[indexPath.row]
   
        detailedVC.movie = theData?.results[indexPath.row]
        navigationController?.pushViewController(detailedVC, animated: true)
    }
    @IBAction func top20Button(_ sender: Any) {
        let gv = GenreView()
        gv.genreDelegate = self
     navigationController?.present(gv, animated: true, completion: nil)
    }
    
    func sendVariableBack(genre:Int) {
       
        chosenGenre = genre
    }
    func getTop20(){
        spinner.startAnimating()
        DispatchQueue.global(qos: .userInitiated).async
            {
                //fetch data from JSON for Tableview
                self.fetchJSONDataForTop20()
                
                //cache images from JSON for Tableview
                //                self.fetchImages()
                //
                DispatchQueue.main.async {
                    self.collectionView.reloadData()
                    self.spinner.stopAnimating()
                    self.waiting = true
                    
                }
        }
    }
    func fetchJSONDataForTop20(){
    theImageCache = []
        if(chosenGenre == 0){
            let url = URL(string:"https://api.themoviedb.org/3/discover/movie?api_key=3040d0a153f1c0e14e4ca405896776c6&language=en-US&sort_by=popularity.desc&include_adult=false&include_video=false&page=1")
            let data = try! Data(contentsOf: url!)
            theData = try! JSONDecoder().decode(APIResults.self, from: data)
            fetchPosterImages(movieArray: (theData?.results)!)
        }else{
            let url = URL(string:"https://api.themoviedb.org/3/discover/movie?api_key=3040d0a153f1c0e14e4ca405896776c6&language=en-US&sort_by=popularity.desc&include_adult=false&include_video=false&page=1&with_genres=\(chosenGenre!)")
            let data = try! Data(contentsOf: url!)
            theData = try! JSONDecoder().decode(APIResults.self, from: data)
            fetchPosterImages(movieArray: (theData?.results)!)
        }
        
        
    }
}

