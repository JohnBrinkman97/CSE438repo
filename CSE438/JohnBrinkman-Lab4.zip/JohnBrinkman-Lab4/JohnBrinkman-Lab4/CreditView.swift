//
//  CreditView.swift
//  JohnBrinkman-Lab4
//
//  Created by John W Brinkman on 7/15/18.
//  Copyright © 2018 John W Brinkman. All rights reserved.
//

import UIKit

class CreditView: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor.white
        
        let theImageFrame = CGRect(x: 0, y: 40 , width: view.frame.width, height:view.frame.height/2)
    
        self.title = "Attribution"
        let imageView = UIImageView(frame: theImageFrame)
        imageView.image = #imageLiteral(resourceName: "TMDb")
        imageView.backgroundColor = UIColor.white
        imageView.contentMode = .scaleAspectFit
        view.addSubview(imageView)
        let theTextFrame = CGRect(x: 5, y: imageView.frame.maxY + 30, width: view.frame.width-5, height: 50)
        let textView = UILabel(frame: theTextFrame)
        textView.text = "This product uses the TMDb API but is not endorsed or certified by TMDb."
        textView.textAlignment = .center
        textView.numberOfLines = 0
        textView.lineBreakMode = .byWordWrapping
        view.addSubview(textView)
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    



}
