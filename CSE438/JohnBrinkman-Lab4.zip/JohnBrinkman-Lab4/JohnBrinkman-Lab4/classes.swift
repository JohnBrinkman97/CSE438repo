//
//  classes.swift
//  JohnBrinkman-Lab4
//
//  Created by John W Brinkman on 7/11/18.
//  Copyright © 2018 John W Brinkman. All rights reserved.
//

import Foundation

struct APIResults: Decodable {
    let page: Int
    let total_results: Int
    let total_pages: Int
    var results: [Movie]
}
struct Movie: Codable {
    let id: Int!
    let poster_path: String?
    let title: String
    let release_date: String
    let vote_average: Double
    let overview: String
    let vote_count : Int!
}
struct Video: Codable {
    let type:String?
    let key:String?
}
struct APIvideoResults: Codable{
    let id: Int
    let results: [Video]
}
