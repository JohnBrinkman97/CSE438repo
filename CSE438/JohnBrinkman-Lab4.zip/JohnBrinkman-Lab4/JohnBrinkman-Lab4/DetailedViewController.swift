//
//  DetailedViewController.swift
//  JohnBrinkman-Lab4
//
//  Created by John W Brinkman on 7/12/18.
//  Copyright © 2018 John W Brinkman. All rights reserved.
//

//  BASE CODE TAKEN FROM:
////  DetailedViewController.swift
////  InClassDemo2
////
////  Created by Todd Sproull on 7/10/18.
////  Copyright © 2018 Todd Sproull. All rights reserved.
////

import UIKit
class DetailedViewController: UIViewController {
    var movie:Movie!
    var image: UIImage!
    var videoURL:String = ""
 
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        
        view.backgroundColor = UIColor.white
        let navBarHeight = self.navigationController?.navigationBar.frame.height
        self.title = movie.title
        let theImageFrame = CGRect(x: view.frame.minX, y: view.frame.minY + navBarHeight! + 20, width: view.frame.width, height:view.frame.height/2 - navBarHeight!) // not sure why navBarHeight isn't enough
        let imageView = UIImageView(frame: theImageFrame)
        imageView.image = image
        imageView.backgroundColor = UIColor.gray
        imageView.contentMode = .scaleAspectFit
        view.addSubview(imageView)
        
        let theTextFrame1 = CGRect(x: 0, y: imageView.frame.maxY + 10, width: view.frame.width, height: 30)
        let textView1 = UILabel(frame: theTextFrame1)
        textView1.text = movie.release_date
        textView1.textAlignment = .center
        view.addSubview(textView1)
        let theTextFrame2 = CGRect(x: 0, y: textView1.frame.maxY + 10, width: view.frame.width, height: 30)
        let textView2 = UILabel(frame: theTextFrame2)
        textView2.text = "Rating: \(String(format: "%.1f",movie.vote_average))/10"
        textView2.textAlignment = .center
        view.addSubview(textView2)

        //description button
        let buttonFrame = CGRect(x: 0, y: textView2.frame.maxY + 15, width: view.frame.width, height: 20)
        let button = UIButton(frame: buttonFrame)
        button.setTitle("Description", for: .normal)
        button.setTitleColor(UIColor.blue, for: .normal)
        button.addTarget( self, action: #selector(self.descButton(sender:)), for: .touchUpInside)
        view.addSubview(button)
       // Trailer Button
        let videoButtonFrame = CGRect(x: 0, y: button.frame.maxY + 15, width: view.frame.width, height: 20)
        let videoButton = UIButton(frame: videoButtonFrame)
        videoButton.setTitle("View Trailer", for: .normal)
        videoButton.setTitleColor(UIColor.blue, for: .normal)
        videoButton.addTarget( self, action: #selector(self.videoButton(sender:)), for: .touchUpInside)
        view.addSubview(videoButton)
        
        //favorites button
        let favButtonFrame = CGRect(x: view.frame.width - (view.frame.width-40), y: videoButton.frame.maxY + 30, width: view.frame.width - 80, height: 30)
        let favButton = UIButton(frame: favButtonFrame)
        favButton.setTitle("Add to Favorites", for: .normal)
        favButton.setTitleColor(UIColor.blue, for: .normal)
        favButton.layer.cornerRadius = 0.5
        favButton.layer.borderColor = UIColor.blue.cgColor
        favButton.layer.borderWidth = 2
        
       
        
        
        favButton.addTarget( self, action: #selector(self.favButton(sender:)), for: .touchUpInside)
        view.addSubview(favButton)
        DispatchQueue.global(qos: .userInitiated).async {
        self.getVideos()
        }
       
    }
    @objc func descButton(sender: UIButton){
        let dv = DescriptionView()
        dv.overview = movie.overview
        self.modalTransitionStyle = .partialCurl
        self.present(dv, animated: true, completion: nil)
      
    }
    @objc func favButton(sender: UIButton){
        
        

        let thepath = Bundle.main.path(forResource: "movies", ofType: "db")
       
        let contactDB = FMDatabase(path: thepath)
       
        let valueArray:[Any] = [movie.id, movie.title, movie.poster_path ?? "", movie.release_date, movie.vote_average, movie.overview, movie.vote_count]
        if !(contactDB.open()) {
            print("Unable to open database")
            return
        } else {
            do{
                try contactDB.executeUpdate("insert into movies values (?,?,?,?,?,?,?);", values: valueArray)
                    print("executed")
            } catch let error as NSError {
                print("failed \(error)")
                if error.code == 19{
                   
                    let alert = UIAlertController(title: "Movie already saved to favorites!", message: "", preferredStyle: .alert)
                    alert.addAction(UIAlertAction(title: NSLocalizedString("OK", comment: "Default action"), style: .default, handler: { _ in
                        NSLog("The \"OK\" alert occured.") // https://developer.apple.com/documentation/uikit/uialertcontroller?changes=_4
                    }))
                    self.present(alert, animated: true)
                }
            }
        }
        
    }
    func getVideos(){
        let url = URL(string:"https://api.themoviedb.org/3/movie/\(movie.id!)/videos?api_key=3040d0a153f1c0e14e4ca405896776c6&language=en-US")
        let data = try! Data(contentsOf: url!)
        let temp = try! JSONDecoder().decode(APIvideoResults.self, from: data)
        for video in temp.results{
            if video.type == "Trailer"{
                    self.videoURL = "https://www.youtube.com/watch?v=\(video.key ?? " ")"
                break
            }
        }
    }
    @objc func videoButton(sender: UIButton){
        if !videoURL.isEmpty{
            UIApplication.shared.open(URL(string : videoURL)!, options: [:], completionHandler: { (status) in
            })
        }else{
            let alert = UIAlertController(title: "Movie Has No Trailer Link", message: "", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: NSLocalizedString("OK", comment: "Default action"), style: .default, handler: { _ in
                NSLog("The \"OK\" alert occured.") // https://developer.apple.com/documentation/uikit/uialertcontroller?changes=_4
            }))
            self.present(alert, animated: true)
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destinationViewController.
     // Pass the selected object to the new view controller.
     }
     */
    
}
