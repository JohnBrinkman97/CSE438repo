//
//  GenreView.swift
//  JohnBrinkman-Lab4
//
//  Created by John W Brinkman on 7/15/18.
//  Copyright © 2018 John W Brinkman. All rights reserved.
//

import UIKit
protocol sendBack:class { // protocol to send variable backwards
    func sendVariableBack(genre:Int)
}
class GenreView: UIViewController, UITableViewDelegate, UITableViewDataSource {
    weak var genreDelegate:sendBack?
    
    let genres:[String:Int] = ["All":0, "Action":28,"Adventure":12,"Animation":16,"Comedy":35,"Crime":80,"Documentary":99,"Drama":18,"Family":10751,"Fantasy":14,"History":36,"Horror":27,"Music":10402,"Mystery":9648,"Romance":10749,"Science Fiction":878,"TV Movie":10770,"Thriller":53,"War":10752,"Western":37]
    

    override func viewDidLoad() {
        super.viewDidLoad()
        let tableView = UITableView(frame: view.frame)
        tableView.delegate = self
        tableView.dataSource = self
        view.backgroundColor = UIColor.white
        view.addSubview(tableView)
        // Do any additional setup after loading the view.
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return genres.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell(style: .default, reuseIdentifier: nil)
        cell.textLabel?.text = Array(genres)[indexPath.row].key
        return cell
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        genreDelegate?.sendVariableBack(genre: Array(genres)[indexPath.row].value) //send variable back
        self.dismiss(animated: true, completion: nil)
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
