//
//  FavoriteViewController.swift
//  JohnBrinkman-Lab4
//
//  Created by John W Brinkman on 7/13/18.
//  Copyright © 2018 John W Brinkman. All rights reserved.
//

import UIKit

class FavoriteViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    var  movieArray:[Movie] = []
    var movieImage:UIImage?
    @IBOutlet weak var tableView:UITableView!
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.view.layoutIfNeeded()
        grabDataFromDB()
        self.tableView.reloadData()
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.dataSource = self
        tableView.delegate = self
        tableView.reloadData()
        
        // Do any additional setup after loading the view.
    }
    

    func grabDataFromDB() {
        
        let thepath = Bundle.main.path(forResource: "movies", ofType: "db")
        
        let contactDB = FMDatabase(path: thepath)
        
        if !(contactDB.open()) {
            print("Unable to open database")
            return
        } else {
            do{
                let results = try contactDB.executeQuery("select * from movies" , values: nil)
                
                movieArray = []
                while (results.next()) {
                    
                    let title = results.string(forColumn: "title")
                    let id = Int(results.int(forColumn: "id"))
                    let poster_path = results.string(forColumn: "poster_path")
                    let overview = results.string(forColumn: "overview")
                    let vote_count = Int(results.int(forColumn: "vote_count"))
                    let vote_average = results.double(forColumn: "vote_average")
                    let release_date = results.string(forColumn: "release_date")
                    let newMovie = Movie(id: id, poster_path: poster_path, title: title!, release_date: release_date!, vote_average: vote_average, overview: overview!, vote_count: vote_count)
                  
                    movieArray.append(newMovie)
                 
                }
                
            } catch let error as NSError {
                print("failed \(error)")
       
        }
        
        
    }
    
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell(style: .default, reuseIdentifier: nil)
        cell.textLabel?.text = movieArray[indexPath.row].title
     
        //myCell.textLabel!.text = myArray[indexPath.row]
        return cell
        
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return movieArray.count
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let dv = DetailedViewController()
        dv.movie = movieArray[indexPath.row]
        getImage(poster_path: movieArray[indexPath.row].poster_path)
        dv.image = movieImage
        navigationController?.pushViewController(dv, animated: true)
       // self.present(dv, animated: true, completion: nil)
    }

    func getImage(poster_path:String?) {

            let defaultImage = "8uO0gUM8aNqYLs1OsTBQiXu0fEv.jpg" // just a random image.. url is nil without it for some reason (not sure why the if statement doesn't prevent that, the 'noImage' image is used anyway)
        if poster_path != nil && !(poster_path?.isEmpty)!{
                let url = URL(string: "https://image.tmdb.org/t/p/original/\(poster_path ?? defaultImage )")
                let data = try? Data(contentsOf: url!)
                let image  = UIImage(data: data!)
                movieImage = image
            }else{
                let image = #imageLiteral(resourceName: "image_unavailable.png")
                movieImage = image
            }
    }
    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        return true
    }
    
    func tableView(_ tableView: UITableView, trailingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
        let delete = UIContextualAction(style: .destructive, title: "Delete", handler: { (ac:UIContextualAction, view:UIView, success:(Bool) -> Void) in
            let thepath = Bundle.main.path(forResource: "movies", ofType: "db")
            let contactDB = FMDatabase(path: thepath)
            if !(contactDB.open()) {
                print("Unable to open database")
                return
            } else {
                do{
                    try contactDB.executeUpdate("delete from movies where id = ?;", values: ([self.movieArray[indexPath.row].id]))
                    
                    self.movieArray.remove(at: indexPath.row)
                    self.tableView.reloadData()
                } catch let error as NSError {
                    print("failed \(error)")
                }
            }
            success(true)
        })
        delete.backgroundColor = UIColor.red
        return UISwipeActionsConfiguration(actions: [delete])
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
