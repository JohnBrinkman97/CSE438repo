//
//  ViewController.swift
//  Lab1_Brinkman
//
//  Created by John W Brinkman on 6/17/18.
//  Copyright © 2018 John W Brinkman. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var finalPrice: UILabel!
    
    @IBOutlet weak var originalPriceValue: UITextField!
    @IBOutlet weak var discountValue: UITextField!
    @IBOutlet weak var salesTaxValue: UITextField!
    
    @IBOutlet weak var cartPrice: UILabel!
    var cartTotal:Float = 0.0
    var displayPrice:Float = 0.0
    var discountedValue:Float = 0.0
    var salesTaxValueFloat = 0.0
    
    
    @IBAction func originalPrice(_ sender: Any) {
      somethingChanged()
    }
  
    @IBAction func discount(_ sender: Any) {
        somethingChanged()
    }
    @IBAction func salesTax(_ sender: Any) {
        somethingChanged()
    }
   
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        self.view.addGestureRecognizer(UITapGestureRecognizer(target: self.view, action: #selector(UIView.endEditing(_:))))
        print("Hello")
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
   
    func somethingChanged() {
        if let origPrice = Float(originalPriceValue.text!){
            if(origPrice >= 0){
                displayPrice = origPrice
                print(displayPrice)
            finalPrice.text = String(format: "$%.02f", displayPrice)
            
            if let discountVal = Float(discountValue.text!){
               discountValue = discountVal
                if(discountValue < 100.0 && discountValue >= 0) {
                    displayPrice = origPrice - (discountValue/100.0)*origPrice
                     print(displayPrice + "1")
                    finalPrice.text = String(format: "$%.02f", displayPrice)
                }
                if let taxVal = Float(salesTaxValue.text!){
                    taxValue = taxVal
                    if(discountValue < 100.0 && taxValue < 100.0 && discountValue >= 0 && taxValue >= 0) {
                          displayPrice = origPrice - (discountValue/100.0)*origPrice + (taxValue/100.0)*(origPrice - (discountValue/100.0)*origPrice)
                         print(displayPrice + "2")
                        finalPrice.text = String(format: "$%.02f", displayPrice)
                    } else{ displayPrice = 0}
                }
            }else{
                if let taxVal = Float(salesTaxValue.text!){
                    taxValue = taxVal
                    if(taxValue < 100.0 && taxValue >= 0) {
                        displayPrice = origPrice + (taxValue/100.0)*origPrice
                         print(displayPrice + "3")
                        finalPrice.text = String(format: "$%.02f", displayPrice)
                    }
                    else{ displayPrice = 0}
                }
            }
            }
        }
        else{
            displayPrice = 0
            finalPrice.text = "$0.00"
        }
    }
    @IBAction func cartButton(_ sender: Any) {
        if displayPrice >= 0 {
        cartTotal += displayPrice
        cartPrice.text = String(format: "$%.02f", cartTotal)
        }else { displayPrice = 0}
    }
    @IBAction func clearButton(_ sender: Any) {
       
        cartTotal = 0.0
        cartPrice.text=String(format: "$%.02f", cartTotal)
    }
    
}

