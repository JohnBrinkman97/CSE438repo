import XCTest

public class VariablesTests: XCTestCase {}
