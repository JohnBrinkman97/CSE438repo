import XCTest

public class ProtocolsTests: XCTestCase {}
