import XCTest

public class EnumsTests: XCTestCase {}
