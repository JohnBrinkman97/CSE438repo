import XCTest

public class CollectionsTests: XCTestCase {}
