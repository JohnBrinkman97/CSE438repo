//
//  ViewController.swift
//  Lab1_Brinkman
//
//  Created by John W Brinkman on 6/17/18.
//  Copyright © 2018 John W Brinkman. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var finalPrice: UILabel!
    
    @IBOutlet weak var originalPriceValue: UITextField!
    @IBOutlet weak var discountValue: UITextField!
    @IBOutlet weak var salesTaxValue: UITextField!
    
    @IBOutlet weak var cartPrice: UILabel!
    var cartTotal:Float = 0.0
    var displayPrice:Float = 0.0
   
    
    
    @IBAction func originalPrice(_ sender: Any) {
      somethingChanged()
    }
  
    @IBAction func discount(_ sender: Any) {
        somethingChanged()
    }
    @IBAction func salesTax(_ sender: Any) {
        somethingChanged()
    }
   
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        self.view.addGestureRecognizer(UITapGestureRecognizer(target: self.view, action: #selector(UIView.endEditing(_:))))
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
   
    func somethingChanged() {
        if let origPrice = Float(originalPriceValue.text!){
            if(origPrice >= 0){
                displayPrice = origPrice
            finalPrice.text = String(format: "$%.02f", displayPrice)
            }
            if let discountVal = Float(discountValue.text!){
               displayPrice = origPrice - (discountVal/100.0)*origPrice
                if(displayPrice > 0 && discountVal < 100.0) {
                    finalPrice.text = String(format: "$%.02f", displayPrice)
                }
                if let taxVal = Float(salesTaxValue.text!){
                     displayPrice = origPrice - (discountVal/100.0)*origPrice + (taxVal/100.0)*(origPrice - (discountVal/100.0)*origPrice)
                    if(displayPrice > 0 && discountVal < 100.0 && taxVal < 100.0) {
                        finalPrice.text = String(format: "$%.02f", displayPrice)
                    }
                }
            }else{
                if let taxVal = Float(salesTaxValue.text!){
                    displayPrice = origPrice + (taxVal/100.0)*origPrice
                    if(displayPrice > 0 && taxVal < 100.0 ) {
                        finalPrice.text = String(format: "$%.02f", displayPrice)
                    }
                }
            }
        }
        else{
            finalPrice.text = "$0.00"
        }
    }
    @IBAction func cartButton(_ sender: Any) {
        cartTotal += displayPrice
        cartPrice.text = String(format: "$%.02f", cartTotal)
    }
    @IBAction func clearButton(_ sender: Any) {
        cartTotal = 0.0
        cartPrice.text=String(format: "$%.02f", cartTotal)
    }
    
}

