//
//  ViewController.swift
//  studio1
//
//  Created by John W Brinkman on 6/13/18.
//  Copyright © 2018 John W Brinkman. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var logo: UIImageView!
    
    @IBOutlet weak var slider: UISlider!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func sliderAction(_ sender: Any) {
        logo.alpha = CGFloat(slider.value)
       
    }
    
}

